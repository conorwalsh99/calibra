=====
Usage
=====

To use calibra in a project::

    import calibra
