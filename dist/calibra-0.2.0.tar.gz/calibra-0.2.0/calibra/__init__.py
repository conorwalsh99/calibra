"""Top-level package for calibra."""

__author__ = """Conor Walsh"""
__email__ = 'conorwalsh206@gmail.com'
__version__ = '0.1.0'
