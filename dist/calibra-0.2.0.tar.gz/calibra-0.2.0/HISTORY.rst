=======
History
=======

0.1.0 (2024-01-24)
------------------

* First release on PyPI.
