=======
calibra
=======


.. image:: https://img.shields.io/pypi/v/calibra.svg
        :target: https://pypi.python.org/pypi/calibra

.. image:: https://img.shields.io/travis/conorwalsh99/calibra.svg
        :target: https://travis-ci.com/conorwalsh99/calibra

.. image:: https://readthedocs.org/projects/calibra/badge/?version=latest
        :target: https://calibra.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Toolkit for calibration of machine learning classifiers.


* Free software: MIT license
* Documentation: https://calibra.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
